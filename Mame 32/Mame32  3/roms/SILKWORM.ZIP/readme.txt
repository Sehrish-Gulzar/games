
------------------------
Silkworm by TECMO (1988)
------------------------
malcor



Location   Type     File ID    Checksum
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
CPU B6     27256       R1        D712
CPU J3     27256       R2        84CF
CPU J5     27256       R3        B06F
CPU S5     27512       R4        ECBB
CPU S6     27512       R5        CD48
GFX C2     27512       R6        5F8A
GFX D2     27512       R7        2007
GFX E2     27512       R8        42BE
GFX F2     27512       R9        C545
GFX P1     27512       R10       B7D5
GFX P2     27512       R11       2DF3
GFX P2/3   27512       R12       583D
GFX P3     27512       R13       908C
GFX S1     27512       R14       A9C5
GFX S2     27512       R15       D3E6
GFX S2/3   27512       R16       C0BA
GFX S3     27512       R17       81D7


Note:  CPU - CPU PCB         (A-41909, 6217A)
       GFX - Graphics PCB    (B-41909, 6217B)

           - Custom CPU No. 5783 (626 batch)

             This version uses a custom sound processor on a 
             sub-board connected to CN5, located adjacent to the
             sound processor (Z80 CPU). The Z80 is (obviously)
             not installed on this version.

