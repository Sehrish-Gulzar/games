Gunforce 2
Irem, 1994

This game runs on Irem M92 hardware.

Top Board (CPU / Sound)
-----------------------

PCB No: M92-A-B   05C04170B1
CPU   : NEC D70136 (V33)
SND   : Nanao GA20 (80 pin PQFP), YM2151, YM3014
OSC   : 18.000 MHz (Near V33), 26.66666MHz
DIPs  : 8 position (x3)
RAM   : 6264 (x6), 62256 (x2)
PALs  : 16L8 (x3)

Other : Nanao GA21 (136 pin PQFP)
        Nanao GA22 (160 pin PQFP)

ROMs  :
None


Bottom Board (Video)
--------------------

PCB No: M92-B-G   05C04171G1
OSC   : 14.31818 MHz
RAM   : 6264 (x2), 62256 (x2)
PALs  : 16L8 (x2), 16R4 (x1)

Other : Nanao 08J27291A4 (84 pin PLCC)
        Nanao 08J27504A1 (160 pin PQFP)

ROMs  :
A2-H1-A.6F	27C020	\
A2-H0-A.6H	27C020	 |   Main Program
A2-L1-A.8F	27C020	 |
A2-L0-A.8H	27C020	/

A2_SHO.3L	27C512	\
A2_SLO.5L	27C512	/    Sound Program

A2_DA.1L	8M Mask	>    Sound

A2_C0.1A	4M Mask	\
A2_C1.1B	4M Mask  |
A2_C2.3A	4M Mask  |   GFX - Tiles
A2_C3.3B	4M Mask /

A2_000.8A	8M Mask \
A2_010.8B	8M Mask  |
A2_020.8C	8M Mask  |   GFX - Sprites
A2_030.8D	8M Mask /

Developers...
              More info reqd? Email me...
              theguru@emuunlim.com
